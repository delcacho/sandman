#!/usr/bin/env python
# -*- coding: utf-8 -*-
from resources.lib.service import BackgroundService

if __name__ == '__main__':
    BackgroundService().start()
